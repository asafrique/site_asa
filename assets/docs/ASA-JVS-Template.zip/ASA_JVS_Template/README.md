# ASA Journal de Vulgarisation des Sciences — Template LaTeX

Ce dossier contient un **template prêt à l'emploi** pour rédiger des articles (max. ~5 pages) de vulgarisation scientifique au format ASA-JVS.

## Fichiers
- `asa-jvs.cls` : classe LaTeX principale (style, couleurs ASA, en-têtes/pieds, boîtes d'infos).
- `sample-article.tex` : exemple minimal d'article.
- `assets/logoasa.jpg` : logo ASA inclus dans l'en-tête.
- `Makefile` : compilation rapide.
- `sample-refs.bib` : exemple de fichier BibLaTeX (optionnel).

## Compilation
Avec `pdflatex` (simple):
```bash
pdflatex sample-article.tex
```

Avec `latexmk` (recommandé si installé):
```bash
latexmk -pdf sample-article.tex
```

## Conseils éditoriaux (max 5 pages)
- Utiliser l'option `twocolumn` de la classe pour un rendu compact.
- Ajouter des encadrés `keypoints`, `infobox`, `definitionbox` pour rythmer la lecture.
- Préférer des figures larges et légendes explicatives.
- Limiter les équations aux éléments indispensables et les commenter en français courant.
- Un lien, une source, un chiffre : par section principale.

## Métadonnées du journal
Dans le préambule de l'article, vous pouvez définir :
```latex
\renewcommand{\volume}{1}
\renewcommand{\issue}{1}
\renewcommand{\pubyear}{2025}
\renewcommand{\doi}{10.0000/asa-jvs.2025.001}
```

## Licence
Vous êtes libres d'utiliser et d'adapter ce template pour ASA.
